#!/usr/bin/env python3
"""Route Drone Voice to every active physical audio sink, without changing OS defaults."""
import json
import logging
import shlex
import signal
import subprocess
import sys
import threading
from pathlib import Path
ROOT = Path(__file__).resolve().parent
BUS = 'dronevoice_all'
SERVICE = 'dronevoice.service'
LOG = logging.getLogger('all-speakers')


def pactl(*args):
    return subprocess.check_output(['pactl', *args], text=True, stderr=subprocess.PIPE, timeout=8).strip()


def modules():
    found = {}
    for line in pactl('list', 'short', 'modules').splitlines():
        fields = line.split('\t')
        if len(fields) >= 3:
            try:
                props = dict(item.split('=', 1) for item in shlex.split(fields[2]) if '=' in item)
            except ValueError:
                continue
            found[fields[0]] = (fields[1], props)
    return found


def outputs():
    try:
        data = json.loads(pactl('--format=json', 'list', 'sinks'))
        return {s['name'] for s in data if physical(s)}
    except (ValueError, subprocess.SubprocessError):
        return {f[1] for line in pactl('list', 'short', 'sinks').splitlines()
                if len(f := line.split()) >= 2 and physical({'name': f[1]})}


def physical(sink):
    name = sink.get('name', '')
    # Include enabled analog, USB, HDMI and Bluetooth outputs, including SUSPENDED
    # hardware sinks. Exclude virtual sinks to prevent audio routing loops.
    return (name != BUS and (name.startswith(('alsa_output.', 'bluez_output.', 'bluez_sink.'))
            or sink.get('properties', {}).get('device.api') in ('alsa', 'bluez5', 'bluez4')))


class Router:
    def unload(self, ident):
        try:
            pactl('unload-module', str(ident))
        except subprocess.SubprocessError:
            pass

    def sync(self):
        current = modules()
        nulls = [i for i, (name, props) in current.items()
                 if name == 'module-null-sink' and props.get('sink_name') == BUS]
        if not nulls:
            pactl('load-module', 'module-null-sink', 'sink_name='+BUS,
                  'sink_properties=device.description=DroneVoice_All_Speakers',
                  'rate=48000', 'channels=2', 'channel_map=front-left,front-right')
            current = modules()
        desired = outputs()
        attached = set()
        for ident, (name, props) in current.items():
            if name != 'module-loopback' or props.get('source') != BUS+'.monitor':
                continue
            target = props.get('sink')
            if target not in desired or target in attached:
                self.unload(ident)
            else:
                attached.add(target)
        for target in sorted(desired-attached):
            try:
                pactl('load-module', 'module-loopback', 'source='+BUS+'.monitor',
                      'sink='+target, 'source_dont_move=true', 'sink_dont_move=true',
                      'latency_msec=80', 'rate=48000', 'channels=2')
                LOG.info('Output attached: %s', target)
            except subprocess.SubprocessError as exc:
                # One unavailable speaker must not interrupt the others.
                LOG.warning('Output unavailable (%s): %s', target, getattr(exc, 'stderr', '') or exc)
        return desired

    def close(self):
        try:
            current = modules()
            for ident, (name, props) in current.items():
                if name == 'module-loopback' and props.get('source') == BUS+'.monitor':
                    self.unload(ident)
            for ident, (name, props) in current.items():
                if name == 'module-null-sink' and props.get('sink_name') == BUS:
                    self.unload(ident)
        except (OSError, subprocess.SubprocessError):
            pass


def command(test=False):
    args = [str(ROOT/'.venv/bin/python'), str(ROOT/'receiver.py'), '--device', BUS]
    return args+(['--test-audio'] if test else [])


def run_receiver():
    stop = threading.Event()
    signal.signal(signal.SIGTERM, lambda *_: stop.set())
    signal.signal(signal.SIGINT, lambda *_: stop.set())
    router, child = Router(), None
    previous = None
    try:
        while not stop.is_set():
            try:
                active = router.sync()
                if active != previous:
                    LOG.info('Active outputs (%d): %s', len(active), ', '.join(sorted(active)) or 'waiting for speakers')
                    previous = active
                if child is None:
                    child = subprocess.Popen(command())
                elif child.poll() is not None:
                    return child.returncode or 1
            except (OSError, subprocess.SubprocessError) as exc:
                LOG.warning('Waiting for audio server: %s', getattr(exc, 'stderr', '') or exc)
            stop.wait(2)
    finally:
        if child is not None and child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=3)
            except subprocess.TimeoutExpired:
                child.kill(); child.wait()
        router.close()
    return 0


def gui():
    import tkinter as tk
    from tkinter import ttk, messagebox
    window = tk.Tk(); window.title('Drone Voice - All Speakers'); window.geometry('720x260')
    ttk.Label(window, text='Automatic output to ALL connected speakers', font=('', 14)).pack(pady=15)
    ttk.Label(window, text='Bluetooth / AUX / USB / HDMI - no device selection required.').pack()
    status = tk.StringVar(value='Connect speakers. Outputs are refreshed every 2 seconds.')
    def action(which):
        try:
            subprocess.run(['systemctl', '--user', which, SERVICE], check=True, timeout=10)
            status.set('Receiver '+which+' requested.')
        except Exception as exc:
            messagebox.showerror('Drone Voice', str(exc))
    def test():
        try:
            subprocess.run(['systemctl', '--user', 'is-active', '--quiet', SERVICE], check=True, timeout=5)
            subprocess.Popen(command(True))
            status.set('2-second test tone requested on all speakers.')
        except Exception as exc:
            messagebox.showerror('Start receiver first', str(exc))
    bar = ttk.Frame(window); bar.pack(pady=20)
    for label, callback in [('Start', lambda:action('start')), ('Stop', lambda:action('stop')),
                            ('Restart', lambda:action('restart')), ('Test all speakers', test)]:
        ttk.Button(bar, text=label, command=callback).pack(side='left', padx=6)
    ttk.Label(window, textvariable=status, wraplength=680).pack()
    window.mainloop()


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    try:
        if '--run' in sys.argv:
            sys.exit(run_receiver())
        elif '--test-audio' in sys.argv:
            sys.exit(subprocess.call(command(True)))
        else:
            gui()
    except KeyboardInterrupt:
        sys.exit(0)
    except Exception as exc:
        LOG.error('%s', exc); sys.exit(1)
