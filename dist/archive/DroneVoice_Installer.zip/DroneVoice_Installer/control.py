#!/usr/bin/env python3
import json, os, subprocess, sys, time, threading
from pathlib import Path
ROOT=Path(__file__).resolve().parent
CONFIG=ROOT/'settings.json'
SERVICE='dronevoice.service'
def sinks():
    try:
        data=subprocess.check_output(['pactl','--format=json','list','sinks'],text=True,timeout=5)
        return [(s['name'],s.get('description',s['name'])) for s in json.loads(data)]
    except (OSError,ValueError,subprocess.SubprocessError):
        data=subprocess.check_output(['pactl','list','short','sinks'],text=True,timeout=5)
        return [(p[1],p[1]) for line in data.splitlines() if len(p:=line.split())>=2]
def load():
    try: return json.loads(CONFIG.read_text())['device']
    except (OSError,ValueError,KeyError): return ''
def save(device):
    tmp=CONFIG.with_suffix('.tmp'); tmp.write_text(json.dumps({'device':device}),encoding='utf-8'); tmp.replace(CONFIG)
def service(action):
    subprocess.run(['systemctl','--user',action,SERVICE],check=True,timeout=10)
def command(device,test=False):
    cmd=[str(ROOT/'.venv/bin/python'),str(ROOT/'receiver.py')]
    if device: cmd+=['--device',device]
    if test: cmd+=['--test-audio']
    return cmd
def run_receiver():
    device=load()
    for _ in range(60):
        try:
            available=sinks()
            if available and (not device or device in dict(available)):
                return subprocess.call(command(device))
        except (OSError,subprocess.SubprocessError): pass
        time.sleep(1)
    print('Selected audio output unavailable. Service will retry.',flush=True)
    return 1
def choose_cli():
    choices=[('','System default output')]+sinks()
    for i,(name,desc) in enumerate(choices): print(f'{i}: {desc} | {name}')
    i=int(input('Output number [0]: ').strip() or '0')
    if not 0<=i<len(choices): raise ValueError('Invalid number')
    save(choices[i][0])
def gui():
    import tkinter as tk
    from tkinter import ttk,messagebox
    window=tk.Tk(); window.title('Drone Voice - Audio Output'); window.geometry('800x330')
    ttk.Label(window,text='Choose Bluetooth, AUX / analog, USB, or system default.').pack(pady=12)
    ttk.Label(window,text='Connect the device first. AUX requires an analog output or an audio adapter.').pack()
    combo=ttk.Combobox(window,state='readonly',width=105); combo.pack(padx=15,pady=15)
    choices=[]; status=tk.StringVar(value='Ready'); results=__import__('queue').Queue()
    def refresh():
        nonlocal choices
        previous=choices[combo.current()][0] if choices and combo.current()>=0 else load()
        try:
            choices=[('','System default output')]+sinks()
            if previous and previous not in dict(choices): choices.append((previous,'Saved output (disconnected)'))
            combo['values']=[d+(' | '+n if n else '') for n,d in choices]
            combo.current(next((i for i,item in enumerate(choices) if item[0]==previous),0))
        except Exception as exc: messagebox.showerror('Audio devices',str(exc))
    def perform(action):
        try:
            if combo.current()<0: raise ValueError('Select an output first')
            if action=='save':
                save(choices[combo.current()][0]); service('restart')
                status.set('Saved. Receiver restarted; waiting for selected device / UART.')
            else: service(action); status.set('Receiver '+action+' requested')
        except Exception as exc: messagebox.showerror('Drone Voice',str(exc))
    def test():
        if combo.current()<0: return
        test_button.config(state='disabled'); status.set('Playing 2-second tone...')
        device=choices[combo.current()][0]
        def worker():
            try:
                result=subprocess.run(command(device,True),capture_output=True,text=True,timeout=15)
                msg='Test tone sent. Check the selected speaker.' if result.returncode==0 else result.stderr[-1200:]
            except Exception as exc: msg=str(exc)
            results.put(msg)
        threading.Thread(target=worker,daemon=True).start()
    def poll():
        try:
            status.set(results.get_nowait()); test_button.config(state='normal')
        except __import__('queue').Empty: pass
        window.after(100,poll)
    bar=ttk.Frame(window); bar.pack(pady=8)
    ttk.Button(bar,text='Refresh devices',command=refresh).pack(side='left',padx=4)
    test_button=ttk.Button(bar,text='Test sound',command=test); test_button.pack(side='left',padx=4)
    ttk.Button(bar,text='Save and restart',command=lambda:perform('save')).pack(side='left',padx=4)
    ttk.Button(bar,text='Start',command=lambda:perform('start')).pack(side='left',padx=4)
    ttk.Button(bar,text='Stop',command=lambda:perform('stop')).pack(side='left',padx=4)
    ttk.Label(window,textvariable=status,wraplength=750).pack(padx=15,pady=12)
    ttk.Label(window,text='Mission Planner: Target SYS=1, COMP=191. Apply output changes with Save and restart.').pack()
    refresh(); poll(); window.mainloop()
if __name__=='__main__':
    try:
        if '--run' in sys.argv: sys.exit(run_receiver())
        elif '--choose' in sys.argv: choose_cli()
        else: gui()
    except KeyboardInterrupt: sys.exit(0)
    except Exception as exc: print(str(exc),file=sys.stderr); sys.exit(1)
